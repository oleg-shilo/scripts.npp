//npp_shortcut Alt+Q
//css_ref C:\Program Files\Notepad++\plugins\NppScripts\NppScripts.dll
//css_ref C:\Program Files\Notepad++\plugins\NppScripts\NppScripts\NppScripts.asm.dll
using System.Text.RegularExpressions;
using System.Text;
using System.Linq;
using System;
using System.Windows.Forms;
using NppScripts;

// to activete the scripted plugin press Alt+Q or select the menu item  
// Plugins->'Automation Scripts'->Sample - Close HTMLXML tag automatically' 
public class Script : NppScript
{
    public Script()
    {
        this.OnNotification = (notification) =>
        {
            if (notification.Header.Code == (uint)SciMsg.SCN_CHARADDED)
            {
                doInsertHtmlCloseTag(notification.Character);
            }
        };
    }

    bool doCloseTag;

    void checkInsertHtmlCloseTag()
    {
        doCloseTag = !doCloseTag;
        Win32.SendMessage(Npp.Editor.Handle, NppMsg.NPPM_SETMENUITEMCHECK, PluginBase._funcItems.Items[this.ScriptId]._cmdID, doCloseTag ? 1 : 0);
    }

    public override void Run()
    {
        checkInsertHtmlCloseTag();
    }

    void doInsertHtmlCloseTag(char newChar)
    {
        var docType = LangType.L_TEXT;
        Win32.SendMessage(Npp.Editor.Handle, NppMsg.NPPM_GETCURRENTLANGTYPE, 0, ref docType);
        bool isDocTypeHTML = (docType == LangType.L_HTML || docType == LangType.L_XML || docType == LangType.L_PHP);

        if (doCloseTag && isDocTypeHTML)
        {
            var text_on_left = Npp.TextBeforeCaret();

            if (text_on_left.EndsWith(">"))
            {
                var regex = new Regex(@"<\s*\w+");
                var lastMatch = regex.Matches(text_on_left).Cast<Match>().LastOrDefault();

                // Plugin.Output.WriteLine(lastMatch.Value);

                if (lastMatch != null && !lastMatch.Value.StartsWith("</"))
                {
                    var closingTag = lastMatch.Value.Replace("<", "</") + ">";

                    var pos = Npp.CurrentDocument.GetSelectionEnd();

                    Npp.CurrentDocument.BeginUndoAction();
                    Npp.CurrentDocument.ReplaceSel(closingTag);
                    Npp.CurrentDocument.EndUndoAction();
                    Npp.CurrentDocument.SetSel(pos, pos);
                }
            }
        }
    }
}