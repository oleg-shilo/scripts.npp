//css_dir C:\Program Files\Notepad++\plugins\NppScripts
//css_ref NppScripts.dll
//css_ref NppScripts\NppScripts.asm.dll
using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        // Open a new document
        Npp.SendMenuCommand(NppMenuCmd.IDM_FILE_NEW);
        // you can also do it with Win API SendMessage
        //  Win32.SendMessage(Npp.Editor.Handle, (uint)NppMsg.NPPM_MENUCOMMAND, 0, NppMenuCmd.IDM_FILE_NEW);

        // Say hello now :
        Npp.CurrentDocument.SetText("Hello, Notepad++... from .NET!");
    }
}