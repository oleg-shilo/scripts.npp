//css_ref C:\Program Files\Notepad++\plugins\NppScripts\NppScripts.dll
//css_ref C:\Program Files\Notepad++\plugins\NppScripts\NppScripts\NppScripts.asm.dll
using System.Threading.Tasks;
using System.Threading;
using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        Hello();
        Task.Factory.StartNew(callbackHelloFX);
    }

    void Hello()
    {
        Npp.SendMenuCommand(NppMenuCmd.IDM_FILE_NEW);
        Npp.CurrentDocument.SetText("Hello, Notepad++... from .NET!");
    }

    void callbackHelloFX()
    {
        IntPtr curScintilla = Npp.CurrentDocument.Handle;
        int currentZoomLevel = (int)Win32.SendMessage(curScintilla, SciMsg.SCI_GETZOOM, 0, 0);
        int i = currentZoomLevel;

        for (int j = 0; j < 4; j++)
        {
            for (; i >= -10; i--)
            {
                Win32.SendMessage(curScintilla, SciMsg.SCI_SETZOOM, i, 0);
                Thread.Sleep(30);
            }

            Thread.Sleep(100);
            for (; i <= 20; i++)
            {
                Thread.Sleep(30);
                Win32.SendMessage(curScintilla, SciMsg.SCI_SETZOOM, i, 0);
            }

            Thread.Sleep(100);
        }

        for (; i >= currentZoomLevel; i--)
        {
            Thread.Sleep(30);
            Win32.SendMessage(curScintilla, SciMsg.SCI_SETZOOM, i, 0);
        }
    }
}