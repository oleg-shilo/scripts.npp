using System.Windows.Forms;
using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        string path;
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_GETCURRENTDIRECTORY, 0, out path);
        MessageBox.Show(path);
    }
}
