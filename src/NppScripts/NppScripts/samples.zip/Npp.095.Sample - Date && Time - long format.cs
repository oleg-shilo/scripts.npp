using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        string dateTime = DateTime.Now.ToShortTimeString() + " " + DateTime.Now.ToLongDateString();
        Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_REPLACESEL, 0, dateTime);
    }
}