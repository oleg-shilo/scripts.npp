//npp_shortcut Alt+Q
using System.Text.RegularExpressions;
using System.Text;
using System;
using System.Windows.Forms;
using NppScripts;


//to activete the scripted plugin press Alt+Q or select the menu item PLugins->'Automation Scripts'->Sample - Close HTMLXML tag automatically' 
public class Script : NppScript
{
    public Script()
    {
        this.OnNotification = (notification) =>
        {
            if(notification.nmhdr.code == (uint)SciMsg.SCN_CHARADDED)
            {
                doInsertHtmlCloseTag((char)notification.ch);
            }
        };
    }

    public override void Run()
    {
        checkInsertHtmlCloseTag();
    }

    bool doCloseTag;

    void checkInsertHtmlCloseTag()
    {
        doCloseTag = !doCloseTag;
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_SETMENUITEMCHECK, Plugin.FuncItems.Items[this.ScriptId]._cmdID, doCloseTag ? 1 : 0);
    }

    void doInsertHtmlCloseTag(char newChar)
    {
        LangType docType = LangType.L_TEXT;
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_GETCURRENTLANGTYPE, 0, ref docType);
        bool isDocTypeHTML = (docType == LangType.L_HTML || docType == LangType.L_XML || docType == LangType.L_PHP);
        if (doCloseTag && isDocTypeHTML)
        {
            if (newChar == '>')
            {
                int bufCapacity = 512;
                IntPtr hCurrentEditView = Npp.CurrentScintilla;
                int currentPos = (int)Win32.SendMessage(hCurrentEditView, SciMsg.SCI_GETCURRENTPOS, 0, 0);
                int beginPos = currentPos - (bufCapacity - 1);
                int startPos = (beginPos > 0) ? beginPos : 0;
                int size = currentPos - startPos;

                if (size >= 3)
                {
                    using (Sci_TextRange tr = new Sci_TextRange(startPos, currentPos, bufCapacity))
                    {
                        Win32.SendMessage(hCurrentEditView, SciMsg.SCI_GETTEXTRANGE, 0, tr.NativePointer);
                        string buf = tr.lpstrText;

                        if (buf[size - 2] != '/')
                        {
                            StringBuilder insertString = new StringBuilder("</");

                            int pCur = size - 2;
                            for (; (pCur > 0) && (buf[pCur] != '<') && (buf[pCur] != '>');)
                                pCur--;

                            if (buf[pCur] == '<')
                            {
                                pCur++;

                                Regex regex = new Regex(@"[\._\-:\w]");
                                while (regex.IsMatch(buf[pCur].ToString()))
                                {
                                    insertString.Append(buf[pCur]);
                                    pCur++;
                                }

                                insertString.Append('>');

                                if (insertString.Length > 3)
                                {
                                    Win32.SendMessage(hCurrentEditView, SciMsg.SCI_BEGINUNDOACTION, 0, 0);
                                    Win32.SendMessage(hCurrentEditView, SciMsg.SCI_REPLACESEL, 0, insertString);
                                    Win32.SendMessage(hCurrentEditView, SciMsg.SCI_SETSEL, currentPos, currentPos);
                                    Win32.SendMessage(hCurrentEditView, SciMsg.SCI_ENDUNDOACTION, 0, 0);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}