//npp_shortcut Ctrl+Shift+T
using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        try
        {
            string text = Npp.GetAllText();
            Npp.SetAllText(text.Replace("\t", "    "));
        }
        catch(Exception e)
        {
            Npp.Output.Clear();
            Npp.Output.WriteLine("'Replace Tabs' Error:\r\n" + e.Message);
        }
    }
}