//css_dir %PROGRAMFILES% (x86)\Notepad++\plugins
using System.Threading.Tasks;
using System.Threading;
using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        Hello();
        Task.Factory.StartNew(callbackHelloFX);
    }

    void Hello()
    {
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_MENUCOMMAND, 0, NppMenuCmd.IDM_FILE_NEW);
        Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETTEXT, 0, "Hello, Notepad++... from .NET!");
    }

    void callbackHelloFX()
    {
        IntPtr curScintilla = Npp.CurrentScintilla;
        int currentZoomLevel = (int)Win32.SendMessage(curScintilla, SciMsg.SCI_GETZOOM, 0,0);
        int i = currentZoomLevel;
        for (int j = 0; j < 4; j++)
        {
            for (; i >= -10; i--)
            {
                Win32.SendMessage(curScintilla, SciMsg.SCI_SETZOOM, i,0);
                Thread.Sleep(30);
            }

            Thread.Sleep(100);
            for (; i <= 20; i++)
            {
                Thread.Sleep(30);
                Win32.SendMessage(curScintilla, SciMsg.SCI_SETZOOM, i,0);
            }

            Thread.Sleep(100);
        }

        for (; i >= currentZoomLevel; i--)
        {
            Thread.Sleep(30);
            Win32.SendMessage(curScintilla, SciMsg.SCI_SETZOOM, i,0);
        }
    }
}