using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        // Open a new document
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_MENUCOMMAND, 0, NppMenuCmd.IDM_FILE_NEW);
        // Say hello now :
        Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETTEXT, 0, "Hello, Notepad++... from .NET!");
    }
}
